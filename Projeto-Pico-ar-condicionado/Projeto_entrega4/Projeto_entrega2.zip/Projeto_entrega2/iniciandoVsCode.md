export PICO_SDK_PATH=/home/pi/pico/pico-sdk
code
